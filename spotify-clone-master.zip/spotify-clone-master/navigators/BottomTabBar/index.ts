export { BottomTabBar } from './BottomTabBar';
