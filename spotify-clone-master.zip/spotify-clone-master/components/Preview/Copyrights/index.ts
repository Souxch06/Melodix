export { Copyrights } from './Copyrights';
